import psycopg2
import Model
import View
import Controller

Controller.open_menu()